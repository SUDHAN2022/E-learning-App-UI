import { ArrowLeft, Play, Clock, Star, Users, Download, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Lesson {
  id: string;
  title: string;
  duration: string;
  completed: boolean;
  type: 'video' | 'quiz' | 'assignment';
}

interface CourseDetailsProps {
  courseId: string;
  onBack: () => void;
  onLessonSelect: (lessonId: string, type: string) => void;
}

export function CourseDetails({ courseId, onBack, onLessonSelect }: CourseDetailsProps) {
  // Mock course data
  const course = {
    id: courseId,
    title: 'Complete React Development Bootcamp',
    instructor: 'John Smith',
    duration: '12h 30m',
    rating: 4.8,
    students: 15420,
    image: 'https://images.unsplash.com/photo-1565229284535-2cbbe3049123?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9ncmFtbWluZyUyMGNvZGluZ3xlbnwxfHx8fDE3NTY3MzMwOTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Master React development from scratch. Build real-world projects and learn modern React patterns, hooks, and best practices.',
    progress: 65,
    price: '₹2,999',
    category: 'Programming'
  };

  const lessons: Lesson[] = [
    { id: '1', title: 'Introduction to React', duration: '15m', completed: true, type: 'video' },
    { id: '2', title: 'JSX and Components', duration: '25m', completed: true, type: 'video' },
    { id: '3', title: 'Props and State', duration: '30m', completed: true, type: 'video' },
    { id: '4', title: 'React Hooks Basics', duration: '35m', completed: true, type: 'video' },
    { id: '5', title: 'Quiz: React Fundamentals', duration: '10m', completed: false, type: 'quiz' },
    { id: '6', title: 'Event Handling', duration: '20m', completed: false, type: 'video' },
    { id: '7', title: 'Forms in React', duration: '40m', completed: false, type: 'video' },
    { id: '8', title: 'Context API', duration: '45m', completed: false, type: 'video' },
    { id: '9', title: 'Final Project Setup', duration: '25m', completed: false, type: 'assignment' },
  ];

  const completedLessons = lessons.filter(lesson => lesson.completed).length;
  const progressPercentage = Math.round((completedLessons / lessons.length) * 100);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Play className="w-4 h-4" />;
      case 'quiz':
        return <CheckCircle className="w-4 h-4" />;
      case 'assignment':
        return <Download className="w-4 h-4" />;
      default:
        return <Play className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'video':
        return 'bg-blue-500';
      case 'quiz':
        return 'bg-green-500';
      case 'assignment':
        return 'bg-orange-500';
      default:
        return 'bg-blue-500';
    }
  };

  return (
    <div className="flex-1 pb-20">
      {/* Header */}
      <div className="relative">
        <ImageWithFallback
          src={course.image}
          alt={course.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute inset-0 bg-black/50" />
        
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="absolute top-4 left-4 text-white hover:bg-white/20"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        
        <div className="absolute bottom-4 left-4 right-4 text-white">
          <Badge className="mb-2">{course.category}</Badge>
          <h1 className="text-xl font-medium mb-2">{course.title}</h1>
          <p className="text-white/80 text-sm">{course.instructor}</p>
        </div>
      </div>

      <div className="p-4">
        {/* Course Stats */}
        <div className="flex items-center justify-between mb-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{course.duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span>{course.rating}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{course.students}</span>
          </div>
          <span className="font-medium text-primary">{course.price}</span>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium">Course Progress</h3>
            <span className="text-sm text-muted-foreground">{progressPercentage}%</span>
          </div>
          <Progress value={progressPercentage} className="h-3" />
          <p className="text-xs text-muted-foreground mt-1">
            {completedLessons} of {lessons.length} lessons completed
          </p>
        </div>

        {/* Description */}
        <div className="mb-6">
          <h3 className="font-medium mb-2">About this course</h3>
          <p className="text-muted-foreground text-sm leading-relaxed">
            {course.description}
          </p>
        </div>

        {/* Course Content */}
        <div>
          <h3 className="font-medium mb-3">Course Content</h3>
          <div className="space-y-2">
            {lessons.map((lesson) => (
              <div
                key={lesson.id}
                onClick={() => onLessonSelect(lesson.id, lesson.type)}
                className={`flex items-center p-3 rounded-lg border cursor-pointer transition-colors ${
                  lesson.completed 
                    ? 'bg-green-50 border-green-200 hover:bg-green-100' 
                    : 'bg-card border-border hover:bg-accent'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs mr-3 ${getTypeColor(lesson.type)}`}>
                  {lesson.completed ? (
                    <CheckCircle className="w-4 h-4" />
                  ) : (
                    getTypeIcon(lesson.type)
                  )}
                </div>
                
                <div className="flex-1">
                  <h4 className={`font-medium text-sm ${lesson.completed ? 'text-green-800' : ''}`}>
                    {lesson.title}
                  </h4>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>{lesson.duration}</span>
                    <span>•</span>
                    <span className="capitalize">{lesson.type}</span>
                  </div>
                </div>
                
                {lesson.completed && (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Continue Button */}
        <div className="mt-6">
          <Button 
            className="w-full" 
            onClick={() => {
              const nextLesson = lessons.find(lesson => !lesson.completed);
              if (nextLesson) {
                onLessonSelect(nextLesson.id, nextLesson.type);
              }
            }}
          >
            {progressPercentage === 0 ? 'Start Course' : 'Continue Learning'}
          </Button>
        </div>
      </div>
    </div>
  );
}