import { useState } from 'react';
import { Search, Filter, Flame } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CourseCard } from './CourseCard';

interface Course {
  id: string;
  title: string;
  instructor: string;
  duration: string;
  rating: number;
  students: number;
  image: string;
  category: string;
  progress?: number;
  price: string;
}

interface HomeProps {
  onCourseSelect: (courseId: string) => void;
}

export function Home({ onCourseSelect }: HomeProps) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = ['All', 'Programming', 'Design', 'Business', 'Marketing', 'Data Science'];
  
  const courses: Course[] = [
    {
      id: '1',
      title: 'Complete React Development Bootcamp',
      instructor: 'John Smith',
      duration: '12h 30m',
      rating: 4.8,
      students: 15420,
      image: 'https://images.unsplash.com/photo-1565229284535-2cbbe3049123?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9ncmFtbWluZyUyMGNvZGluZ3xlbnwxfHx8fDE3NTY3MzMwOTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'Programming',
      progress: 65,
      price: '₹2,999'
    },
    {
      id: '2',
      title: 'UI/UX Design Fundamentals',
      instructor: 'Sarah Johnson',
      duration: '8h 45m',
      rating: 4.9,
      students: 8760,
      image: 'https://images.unsplash.com/photo-1661246627090-7ee7c40976f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ24lMjB0dXRvcmlhbHxlbnwxfHx8fDE3NTY3NTIzNDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'Design',
      price: '₹1,999'
    },
    {
      id: '3',
      title: 'Digital Marketing Mastery',
      instructor: 'Mike Chen',
      duration: '15h 20m',
      rating: 4.7,
      students: 12340,
      image: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGVkdWNhdGlvbnxlbnwxfHx8fDE3NTY3NTIzNDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'Marketing',
      price: '₹3,499'
    },
    {
      id: '4',
      title: 'Python for Data Science',
      instructor: 'Dr. Lisa Wang',
      duration: '20h 15m',
      rating: 4.8,
      students: 9850,
      image: 'https://images.unsplash.com/photo-1518818608552-195ed130cdf4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbmxpbmUlMjBsZWFybmluZyUyMGNvdXJzZXxlbnwxfHx8fDE3NTY2NDg5MDd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'Data Science',
      progress: 30,
      price: '₹4,999'
    }
  ];

  const filteredCourses = courses.filter(course => {
    const matchesCategory = selectedCategory === 'All' || course.category === selectedCategory;
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.instructor.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const continueLearningCourses = courses.filter(course => course.progress !== undefined);

  return (
    <div className="flex-1 pb-20">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-4 pt-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-medium">Welcome back, User!</h1>
            <p className="text-primary-foreground/80 text-sm">Continue your learning journey</p>
          </div>
          <div className="flex items-center gap-1 bg-primary-foreground/10 px-2 py-1 rounded-full">
            <Flame className="w-4 h-4 text-orange-400" />
            <span className="text-sm">7 day streak</span>
          </div>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search courses..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-background/10 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/60"
          />
        </div>
      </div>

      <div className="p-4">
        {/* Continue Learning */}
        {continueLearningCourses.length > 0 && (
          <div className="mb-6">
            <h2 className="font-medium mb-3">Continue Learning</h2>
            <div className="space-y-3">
              {continueLearningCourses.map(course => (
                <CourseCard
                  key={course.id}
                  course={course}
                  onClick={() => onCourseSelect(course.id)}
                  showProgress={true}
                />
              ))}
            </div>
          </div>
        )}

        {/* Categories */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-medium">Browse Categories</h2>
            <Button variant="ghost" size="sm">
              <Filter className="w-4 h-4 mr-1" />
              Filter
            </Button>
          </div>
          
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map(category => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "secondary"}
                className="cursor-pointer whitespace-nowrap"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </div>
        </div>

        {/* Featured Courses */}
        <div>
          <h2 className="font-medium mb-3">
            {selectedCategory === 'All' ? 'Featured Courses' : `${selectedCategory} Courses`}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredCourses.map(course => (
              <CourseCard
                key={course.id}
                course={course}
                onClick={() => onCourseSelect(course.id)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}