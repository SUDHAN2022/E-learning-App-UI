import { Trophy, Flame, Target, Calendar, Award, BookOpen, Clock, TrendingUp } from 'lucide-react';
import { Card } from './ui/card';
import { Progress as ProgressBar } from './ui/progress';
import { Badge } from './ui/badge';

export function Progress() {
  const stats = {
    totalCourses: 4,
    completedCourses: 1,
    totalLessons: 45,
    completedLessons: 23,
    currentStreak: 7,
    longestStreak: 15,
    totalStudyTime: 45, // hours
    weeklyGoal: 10, // hours
    weeklyProgress: 7.5 // hours this week
  };

  const achievements = [
    { id: 1, title: 'First Course', description: 'Completed your first course', icon: BookOpen, earned: true, color: 'text-green-600' },
    { id: 2, title: 'Week Warrior', description: '7 day learning streak', icon: Flame, earned: true, color: 'text-orange-600' },
    { id: 3, title: 'Quiz Master', description: 'Scored 100% on 5 quizzes', icon: Target, earned: false, color: 'text-gray-400' },
    { id: 4, title: 'Time Keeper', description: 'Study for 50 hours total', icon: Clock, earned: false, color: 'text-gray-400' },
    { id: 5, title: 'Consistency King', description: '30 day learning streak', icon: Calendar, earned: false, color: 'text-gray-400' },
    { id: 6, title: 'Course Collector', description: 'Complete 10 courses', icon: Trophy, earned: false, color: 'text-gray-400' }
  ];

  const weeklyActivity = [
    { day: 'Mon', hours: 1.5, completed: true },
    { day: 'Tue', hours: 2.0, completed: true },
    { day: 'Wed', hours: 1.0, completed: true },
    { day: 'Thu', hours: 2.5, completed: true },
    { day: 'Fri', hours: 0.5, completed: true },
    { day: 'Sat', hours: 0, completed: false },
    { day: 'Sun', hours: 0, completed: false }
  ];

  const courseProgress = [
    { title: 'Complete React Development', progress: 65, totalLessons: 12, completedLessons: 8 },
    { title: 'Python for Data Science', progress: 30, totalLessons: 15, completedLessons: 5 },
    { title: 'UI/UX Design Fundamentals', progress: 0, totalLessons: 10, completedLessons: 0 },
    { title: 'Digital Marketing Mastery', progress: 0, totalLessons: 18, completedLessons: 0 }
  ];

  return (
    <div className="flex-1 pb-20">
      <div className="p-4">
        <h1 className="text-xl font-medium mb-6">Your Progress</h1>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                <Flame className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.currentStreak}</p>
                <p className="text-xs text-muted-foreground">Day Streak</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalStudyTime}h</p>
                <p className="text-xs text-muted-foreground">Total Time</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.completedCourses}</p>
                <p className="text-xs text-muted-foreground">Completed</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                <Trophy className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{achievements.filter(a => a.earned).length}</p>
                <p className="text-xs text-muted-foreground">Achievements</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Weekly Goal */}
        <Card className="p-4 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium">Weekly Goal</h3>
            <Badge variant="secondary">
              {stats.weeklyProgress}h / {stats.weeklyGoal}h
            </Badge>
          </div>
          <ProgressBar value={(stats.weeklyProgress / stats.weeklyGoal) * 100} className="h-3 mb-3" />
          <p className="text-sm text-muted-foreground">
            {stats.weeklyGoal - stats.weeklyProgress}h left to reach your weekly goal
          </p>
        </Card>

        {/* Weekly Activity */}
        <Card className="p-4 mb-6">
          <h3 className="font-medium mb-4">This Week's Activity</h3>
          <div className="flex items-end justify-between gap-2">
            {weeklyActivity.map((day, index) => (
              <div key={index} className="flex-1 text-center">
                <div 
                  className={`h-20 rounded-t-md mb-2 relative ${
                    day.completed ? 'bg-primary' : 'bg-gray-200'
                  }`}
                  style={{ height: `${Math.max(day.hours * 20, 4)}px` }}
                >
                  {day.hours > 0 && (
                    <span className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs text-muted-foreground">
                      {day.hours}h
                    </span>
                  )}
                </div>
                <span className="text-xs text-muted-foreground">{day.day}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Course Progress */}
        <Card className="p-4 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium">Course Progress</h3>
            <TrendingUp className="w-4 h-4 text-muted-foreground" />
          </div>
          <div className="space-y-4">
            {courseProgress.map((course, index) => (
              <div key={index}>
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-sm font-medium">{course.title}</h4>
                  <span className="text-xs text-muted-foreground">
                    {course.completedLessons}/{course.totalLessons} lessons
                  </span>
                </div>
                <ProgressBar value={course.progress} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">{course.progress}% complete</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Achievements */}
        <Card className="p-4">
          <h3 className="font-medium mb-4">Achievements</h3>
          <div className="grid grid-cols-2 gap-3">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-3 rounded-lg border transition-colors ${
                  achievement.earned 
                    ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200' 
                    : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    achievement.earned ? 'bg-yellow-100' : 'bg-gray-100'
                  }`}>
                    <achievement.icon className={`w-4 h-4 ${achievement.color}`} />
                  </div>
                  {achievement.earned && (
                    <Award className="w-4 h-4 text-yellow-600" />
                  )}
                </div>
                <h4 className={`text-sm font-medium ${achievement.earned ? '' : 'text-gray-600'}`}>
                  {achievement.title}
                </h4>
                <p className={`text-xs ${achievement.earned ? 'text-gray-700' : 'text-gray-500'}`}>
                  {achievement.description}
                </p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}