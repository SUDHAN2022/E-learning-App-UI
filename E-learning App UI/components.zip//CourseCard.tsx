import { Clock, Star, Users } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

interface Course {
  id: string;
  title: string;
  instructor: string;
  duration: string;
  rating: number;
  students: number;
  image: string;
  category: string;
  progress?: number;
  price: string;
}

interface CourseCardProps {
  course: Course;
  onClick: () => void;
  showProgress?: boolean;
}

export function CourseCard({ course, onClick, showProgress = false }: CourseCardProps) {
  return (
    <div 
      onClick={onClick}
      className="bg-card rounded-lg overflow-hidden shadow-sm border border-border cursor-pointer hover:shadow-md transition-shadow"
    >
      <div className="relative">
        <ImageWithFallback
          src={course.image}
          alt={course.title}
          className="w-full h-40 object-cover"
        />
        <Badge className="absolute top-2 left-2" variant="secondary">
          {course.category}
        </Badge>
      </div>
      
      <div className="p-4">
        <h3 className="font-medium mb-2 line-clamp-2">{course.title}</h3>
        <p className="text-muted-foreground text-sm mb-3">{course.instructor}</p>
        
        {showProgress && course.progress !== undefined && (
          <div className="mb-3">
            <div className="flex justify-between items-center mb-1">
              <span className="text-xs text-muted-foreground">Progress</span>
              <span className="text-xs text-muted-foreground">{course.progress}%</span>
            </div>
            <Progress value={course.progress} className="h-2" />
          </div>
        )}
        
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{course.duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
            <span>{course.rating}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-3 h-3" />
            <span>{course.students}</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="font-medium text-primary">{course.price}</span>
        </div>
      </div>
    </div>
  );
}