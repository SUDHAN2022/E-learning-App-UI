import { useState } from 'react';
import { ArrowLeft, CheckCircle, XCircle, Clock, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Card } from './ui/card';

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface QuizProps {
  quizId: string;
  onBack: () => void;
  onComplete: () => void;
}

export function Quiz({ quizId, onBack, onComplete }: QuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({});
  const [showResult, setShowResult] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes

  // Mock quiz data
  const quiz = {
    id: quizId,
    title: 'React Fundamentals Quiz',
    description: 'Test your understanding of React basics',
    duration: '10 minutes',
    totalQuestions: 5
  };

  const questions: Question[] = [
    {
      id: '1',
      question: 'What is the primary purpose of React Hooks?',
      options: [
        'To replace class components entirely',
        'To use state and lifecycle methods in functional components',
        'To improve performance of React applications',
        'To handle routing in React applications'
      ],
      correctAnswer: 1,
      explanation: 'React Hooks allow you to use state and other React features in functional components without writing a class.'
    },
    {
      id: '2',
      question: 'Which Hook is used to manage component state?',
      options: [
        'useEffect',
        'useContext',
        'useState',
        'useReducer'
      ],
      correctAnswer: 2,
      explanation: 'useState is the hook used to manage local component state in functional components.'
    },
    {
      id: '3',
      question: 'When does useEffect run by default?',
      options: [
        'Before the component renders',
        'After every render',
        'Only on component mount',
        'Only when dependencies change'
      ],
      correctAnswer: 1,
      explanation: 'useEffect runs after every render by default, including the first render and every update.'
    },
    {
      id: '4',
      question: 'What does the dependency array in useEffect control?',
      options: [
        'The order of effects execution',
        'When the effect should run',
        'The cleanup function behavior',
        'The effect\'s return value'
      ],
      correctAnswer: 1,
      explanation: 'The dependency array controls when the effect should run - it only runs when one of the dependencies changes.'
    },
    {
      id: '5',
      question: 'What prefix should custom hooks have?',
      options: [
        'custom',
        'hook',
        'use',
        'my'
      ],
      correctAnswer: 2,
      explanation: 'Custom hooks must start with "use" to follow the rules of hooks and enable React to detect hooks usage.'
    }
  ];

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (answerIndex: number) => {
    if (!isSubmitted) {
      setSelectedAnswers({
        ...selectedAnswers,
        [currentQuestion]: answerIndex
      });
    }
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      handleSubmitQuiz();
    }
  };

  const handleSubmitQuiz = () => {
    setIsSubmitted(true);
    setShowResult(true);
  };

  const getScore = () => {
    let correct = 0;
    questions.forEach((question, index) => {
      if (selectedAnswers[index] === question.correctAnswer) {
        correct++;
      }
    });
    return correct;
  };

  const score = getScore();
  const percentage = Math.round((score / questions.length) * 100);

  if (showResult) {
    return (
      <div className="flex-1 pb-20">
        <div className="p-4">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Course
          </Button>

          <div className="text-center mb-6">
            <div className={`w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center ${
              percentage >= 70 ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
            }`}>
              {percentage >= 70 ? (
                <CheckCircle className="w-10 h-10" />
              ) : (
                <XCircle className="w-10 h-10" />
              )}
            </div>
            
            <h1 className="text-2xl font-medium mb-2">Quiz Complete!</h1>
            <p className="text-muted-foreground mb-4">
              You scored {score} out of {questions.length} questions
            </p>
            
            <div className="text-4xl font-bold text-primary mb-2">{percentage}%</div>
            <p className={`text-sm ${percentage >= 70 ? 'text-green-600' : 'text-red-600'}`}>
              {percentage >= 70 ? 'Great job! You passed!' : 'Keep studying and try again!'}
            </p>
          </div>

          <div className="space-y-4 mb-6">
            {questions.map((question, index) => {
              const userAnswer = selectedAnswers[index];
              const isCorrect = userAnswer === question.correctAnswer;
              
              return (
                <Card key={question.id} className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                      isCorrect ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                    }`}>
                      {isCorrect ? (
                        <CheckCircle className="w-4 h-4" />
                      ) : (
                        <XCircle className="w-4 h-4" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-sm mb-2">Question {index + 1}</h3>
                      <p className="text-sm mb-3">{question.question}</p>
                      
                      <div className="space-y-2 mb-3">
                        {question.options.map((option, optionIndex) => (
                          <div
                            key={optionIndex}
                            className={`p-2 rounded text-sm border ${
                              optionIndex === question.correctAnswer
                                ? 'bg-green-50 border-green-200 text-green-800'
                                : optionIndex === userAnswer && !isCorrect
                                ? 'bg-red-50 border-red-200 text-red-800'
                                : 'bg-gray-50 border-gray-200'
                            }`}
                          >
                            {option}
                          </div>
                        ))}
                      </div>
                      
                      <p className="text-xs text-muted-foreground">
                        <strong>Explanation:</strong> {question.explanation}
                      </p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          <div className="space-y-3">
            {percentage >= 70 ? (
              <Button onClick={onComplete} className="w-full">
                Continue to Next Lesson
              </Button>
            ) : (
              <Button onClick={() => window.location.reload()} variant="outline" className="w-full">
                Retake Quiz
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const currentQuestionData = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="flex-1 pb-20">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>{formatTime(timeLeft)}</span>
          </div>
        </div>
        
        <h1 className="font-medium mb-2">{quiz.title}</h1>
        <div className="flex items-center justify-between text-sm text-muted-foreground mb-3">
          <span>Question {currentQuestion + 1} of {questions.length}</span>
          <span>{Math.round(progress)}% Complete</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Question */}
      <div className="p-4">
        <Card className="p-6 mb-6">
          <h2 className="text-lg font-medium mb-4">{currentQuestionData.question}</h2>
          
          <div className="space-y-3">
            {currentQuestionData.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                className={`w-full p-4 text-left rounded-lg border transition-colors ${
                  selectedAnswers[currentQuestion] === index
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'bg-card hover:bg-accent border-border'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                    selectedAnswers[currentQuestion] === index
                      ? 'border-primary-foreground bg-primary-foreground'
                      : 'border-border'
                  }`}>
                    {selectedAnswers[currentQuestion] === index && (
                      <div className="w-3 h-3 rounded-full bg-primary" />
                    )}
                  </div>
                  <span>{option}</span>
                </div>
              </button>
            ))}
          </div>
        </Card>

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
            disabled={currentQuestion === 0}
            className="flex-1"
          >
            Previous
          </Button>
          
          <Button
            onClick={handleNext}
            disabled={selectedAnswers[currentQuestion] === undefined}
            className="flex-1"
          >
            {currentQuestion === questions.length - 1 ? 'Submit Quiz' : 'Next'}
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}