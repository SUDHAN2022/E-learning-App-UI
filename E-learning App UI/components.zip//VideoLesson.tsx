import { useState } from 'react';
import { ArrowLeft, Play, Pause, RotateCcw, RotateCw, Volume2, Settings, Maximize, BookOpen, MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Slider } from './ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';

interface VideoLessonProps {
  lessonId: string;
  onBack: () => void;
  onComplete: () => void;
}

export function VideoLesson({ lessonId, onBack, onComplete }: VideoLessonProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(245); // 4:05
  const [duration] = useState(1500); // 25:00
  const [volume, setVolume] = useState([80]);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);

  // Mock lesson data
  const lesson = {
    id: lessonId,
    title: 'React Hooks Basics',
    description: 'Learn the fundamentals of React Hooks including useState, useEffect, and custom hooks.',
    duration: '25m',
    courseTitle: 'Complete React Development Bootcamp'
  };

  const transcript = [
    { time: '0:00', text: 'Welcome to this lesson on React Hooks. Today we\'ll cover the basics of useState and useEffect.' },
    { time: '0:30', text: 'React Hooks were introduced in React 16.8 and they allow you to use state and lifecycle methods in functional components.' },
    { time: '1:15', text: 'Let\'s start with the useState hook. This is the most basic hook that allows you to add state to functional components.' },
    { time: '2:30', text: 'The useState hook returns an array with two elements: the current state value and a function to update it.' },
    { time: '4:05', text: 'Now let\'s look at a practical example of how to use useState in a real component.' },
  ];

  const notes = [
    'useState returns [state, setState]',
    'useEffect runs after render',
    'Dependencies array controls when useEffect runs',
    'Custom hooks start with "use"'
  ];

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = (currentTime / duration) * 100;

  return (
    <div className="flex flex-col h-screen bg-black">
      {/* Video Player */}
      <div className="relative flex-1 bg-black">
        {/* Mock Video */}
        <div className="w-full h-full flex items-center justify-center bg-gray-900">
          <div className="text-center text-white">
            <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
              {isPlaying ? (
                <Pause className="w-8 h-8" />
              ) : (
                <Play className="w-8 h-8 ml-1" />
              )}
            </div>
            <p className="text-sm opacity-60">Video Player</p>
          </div>
        </div>

        {/* Back Button */}
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="absolute top-4 left-4 text-white hover:bg-white/20"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>

        {/* Video Controls */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
          {/* Progress Bar */}
          <div className="mb-4">
            <Progress value={progressPercentage} className="h-1 bg-white/20" />
          </div>

          {/* Controls */}
          <div className="flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-white hover:bg-white/20"
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </Button>
              
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <RotateCcw className="w-4 h-4" />
              </Button>
              
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <RotateCw className="w-4 h-4" />
              </Button>
              
              <span className="text-sm">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4" />
                <div className="w-16">
                  <Slider
                    value={volume}
                    onValueChange={setVolume}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20 text-xs"
                onClick={() => setPlaybackSpeed(playbackSpeed === 1 ? 1.5 : playbackSpeed === 1.5 ? 2 : 1)}
              >
                {playbackSpeed}x
              </Button>
              
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <Settings className="w-4 h-4" />
              </Button>
              
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <Maximize className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Lesson Info & Content */}
      <div className="bg-background">
        <div className="p-4 border-b">
          <h1 className="font-medium">{lesson.title}</h1>
          <p className="text-sm text-muted-foreground">{lesson.courseTitle}</p>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="transcript">Transcript</TabsTrigger>
            <TabsTrigger value="notes">Notes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="p-4">
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">About this lesson</h3>
                <p className="text-sm text-muted-foreground">{lesson.description}</p>
              </div>
              
              <Button onClick={onComplete} className="w-full">
                Mark as Complete
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="transcript" className="p-0">
            <ScrollArea className="h-48">
              <div className="p-4 space-y-3">
                {transcript.map((item, index) => (
                  <div
                    key={index}
                    className={`flex gap-3 p-2 rounded cursor-pointer hover:bg-accent ${
                      item.time === '4:05' ? 'bg-primary/10' : ''
                    }`}
                  >
                    <span className="text-xs text-muted-foreground font-mono w-12 flex-shrink-0">
                      {item.time}
                    </span>
                    <p className="text-sm">{item.text}</p>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="notes" className="p-0">
            <ScrollArea className="h-48">
              <div className="p-4 space-y-2">
                {notes.map((note, index) => (
                  <div key={index} className="flex items-start gap-3 p-2 rounded hover:bg-accent">
                    <BookOpen className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <p className="text-sm">{note}</p>
                  </div>
                ))}
                
                <Button variant="outline" size="sm" className="w-full mt-3">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Add Note
                </Button>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}